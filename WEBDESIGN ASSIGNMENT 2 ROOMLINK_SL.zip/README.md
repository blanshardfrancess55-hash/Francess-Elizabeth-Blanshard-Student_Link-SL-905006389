# RoomLink SL --- Student Accommodation

## Project Overview

RoomLink SL is a demonstration website concept designed to help students
explore sample student accommodation listings in Sierra Leone. It
includes room photos, accommodation details, and search/filter options.

## Features

-   Homepage introducing the RoomLink SL accommodation service.
-   Sample accommodation listings in Freetown, Bo, Makeni, and Kenema.
-   Room photos loaded from Unsplash.
-   Search and filtering options for accommodation listings.
-   Responsive layout for desktop and mobile screens.

## How to Open the Website

1.  Download the ZIP file.
2.  Extract all files into a folder on your computer.
3.  Open the `.html` file in a modern web browser such as Chrome, Edge,
    or Firefox.
4.  Keep an internet connection active so the website can load its
    fonts, scripts, and photos.

## Important Notes

-   The listings and contact details are sample data for demonstration
    purposes. They are not verified real accommodation offers.
-   The sample contact number and email address should be replaced with
    real, approved contact details before publishing.
-   The website uses external resources, including React, Babel,
    Tailwind CSS, Google Fonts, and Unsplash images. These resources may
    not load without an internet connection.
-   This is a front-end demonstration. It does not currently include a
    backend database, real user accounts, or live booking/payment
    functionality.

## Customisation

To customise the website, open the HTML file in a code editor such as
Visual Studio Code. You can update the sample listings, prices,
locations, facilities, and contact information in the JavaScript data
near the top of the file.

## Project Name

**RoomLink SL --- Student Accommodation**


## Latest Design Update

The interface has been refreshed using the supplied Student Stay reference: a dark charcoal navigation bar and footer, clearer Home / About Us / Rooms / Contact navigation, an Explore Rooms shortcut, a featured-rooms section, and a highlighted mission panel on the About page. Existing room search, filters, room details, comparison and contact-form validation are retained.

The site remains a front-end academic prototype. Sample listings and contact details are fictional, and the contact form does not send email.


## Contact page update
The Contact page follows the supplied reference layout: contact details on the left, a message form on the right, and a full-width map-location panel below. Contact details and the map are placeholders for this academic prototype. The form validates entries locally and does not send email.


## Latest update

The About Us page now follows the supplied reference layout: introductory text on the left, a real bedroom photograph on the right, and a wide Our Mission panel underneath. The photo loads from Unsplash and requires an internet connection.
