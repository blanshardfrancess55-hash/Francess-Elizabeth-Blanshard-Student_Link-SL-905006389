# RoomLink SL — Student Accommodation

A student accommodation website for RoomLink SL.

## Files
- `RoomLink SL — Student Accommodation (1).html` — the website page, including the HTML and any code/styles/scripts embedded in that file.

## How to open the website
1. Extract this ZIP file.
2. Open `RoomLink SL — Student Accommodation (1).html` in a web browser such as Chrome.

## How to upload to GitHub
1. Open your GitHub repository.
2. Choose **Add file** → **Upload files**.
3. Upload the HTML file and this README file.
4. Enter a commit message and click **Commit changes**.

## Note
The original ZIP you provided contained one HTML file only. It did not contain separate CSS, JavaScript, image, or other files. Any code included in the HTML file remains in that file.
